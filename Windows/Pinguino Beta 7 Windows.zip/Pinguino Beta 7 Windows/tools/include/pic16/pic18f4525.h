/* 
 * pic18f4525.h - PIC18F4525 Device Library Header
 */

#include "pic18f4620.h"

