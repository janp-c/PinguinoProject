/* 
 * pic18f2525.h - PIC18F2525 Device Library Header
 */

#include "pic18f2620.h"

