// pwm library for pinguino
// Jean-Pierre MANDON 2009

void init_PWM11()
{
	TRISCbits.TRISC1=0;		// C1 is an output
	PR2=0xFF;				// init timer 2 period
	T2CON=0x07;				// prescaler and timer 2 on
	CCPR2L=0;				// 8 bits MSB output = 0
	CCP2CON=0x0F;			// configure for PWM 2 bits LSB = 0	
}

void init_PWM12()
{
	TRISCbits.TRISC2=0;		// C2 is an output
	PR2=0xFF;				// init timer 2 period
	T2CON=0x07;				// prescaler and timer 2 on
	CCPR1L=0;				// 8 bits MSB output = 0
	CCP1CON=0x0F;			// configure for PWM 2 bits LSB = 0
}

void set_PWM(int input, int value)
{
	unsigned char octet;
	
	if (input==11)
		{
		//octet=CCP2CON & 0x0F;
		if ((CCP2CON & 0x0F)==0) init_PWM11();
		octet=value & 3;	// extract bit 0 and 1
		octet<<=4;			// rotate left 4 bits
		CCP2CON&=0x0F;		// reset bit 4:5
		CCP2CON|=octet;		// put in CCP2CON 4:5
		value>>=2;			// 8 MSB bits of value
		octet=value;		// in octet
		CCPR2L=octet;		// put in CCPR2L
		}
	if (input==12)
		{
		//octet=CCP1CON & 0x0F;
		if ((CCP1CON & 0x0F)==0) init_PWM12();		
		octet=value & 3;	// extract bit 0 and 1
		octet<<=4;			// rotate left 4 bits
		CCP1CON&=0x0F;		// reset bit 4:5
		CCP1CON|=octet;		// put in CCP2CON 4:5
		value>>=2;			// 8 MSB bits of value
		octet=value;		// in octet
		CCPR1L=octet;		// put in CCPR1L			
		}
}

