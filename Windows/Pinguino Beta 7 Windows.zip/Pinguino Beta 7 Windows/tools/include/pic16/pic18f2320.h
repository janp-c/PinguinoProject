/* 
 * pic18f2320.h - PIC18F2320 Device Library Header
 */

#include "pic18f2220.h"

