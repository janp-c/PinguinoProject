/* 
 * pic18f4320.h - PIC18F4320 Device Library Header
 */

#include "pic18f4220.h"

