/* 
 * pic18f1320.h - PIC18F1320 Device Library Header
 */

#include "pic18f1220.h"

