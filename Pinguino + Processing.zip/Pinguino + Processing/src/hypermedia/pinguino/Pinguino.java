/**
 * (./) Pinguino.java, 12/03/09
 * (by) Jean-Pierre Mandon, Douglas Edric Stanley & Stéphane Cousot
 * (cc) some right reserved
 *
 
 * Pinguino is an Arduino-like board based on a PIC Microcontroller. Pinguino use the libusbJava 
 * wrapper to communicate with USB device. Many thanks to Andreas Schläpfer for this job.
 * For more information about Pinguino see the home page at http://hackinglab.org/pinguino/
 * 
 *
 * Part of the Processing/Java Libraries project, for the Atelier Hypermedia and Atelier Mécatronique,
 * art school of Aix-en-Provence for the Pinguino, Processing and Java community of course.
 *
 * -› http://ubaa.net/shared/processing/
 * -› http://hackinglab.org/pinguino/
 * -› http://www.processing.org/
 * -› http://libusbjava.sourceforge.net/wp/
 *
 *
 *
 * THIS LIBRARY IS RELEASED UNDER A CREATIVE COMMONS GNU LESSER GENERAL PUBLIC LICENSE
 * ‹ http://creativecommons.org/licenses/LGPL/2.1/ ›
 */



// package name
package hypermedia.pinguino;


// java librairies
import processing.core.*;
import ch.ntb.usb.LibusbJava;
import ch.ntb.usb.Device;
import ch.ntb.usb.USB;
import ch.ntb.usb.USBException;



/**
 * Main object to communicate with Pinguino board via USB port.
 * 
 * <div class="hide">
 * <p>You can test all implemented method with this small program.</p>
 * <!--pre>
 *
 *	import hypermedia.pinguino.Pinguino;
 *
 *	public class PinguinoTest {
 *
 *		OpenCV cv = null;  // OpenCV object
 *
 *		// Initialise Objects
 *		public void setup() {
 *		    size( 640, 480 );              // set frame size
 *		    cv = new OpenCV( this );       // link OpenCV process to this PApplet
 *		    cv.capture( width, height );   // start video stream
 *		}
 *
 *		// Display the input camera stream in frame
 *		public void draw() {
 *		    cv.read();
 *		    image( cv.image(), 0, 0 );
 *		}
 *
 *		// Call the PApplet main method
 *		public static void main( String[] args ) {
 *		    PApplet.main( new String[]{"OpenCV_PApplet"} );
 *		} 
 *	}
 *
 * </pre-->
 * </div>
 *
 * @author Jean-Pierre Mandon		http://hackinglab.org/
 * @author Douglas Edric Stanley	http://www.abstractmachine.net/
 * @author Cousot Stéphane			http://ubaa.net/
 * @version 0.1 12/03/09
 * 
 * @usage Application
 */
public class Pinguino {
	
	
	
	/**
	 * Digital pin status.
	 */
	public static final int HIGH = 1;
	public static final int LOW  = 0;
	
	/**
	 * Default timeout value in milliseconds.
	 */
	public final int DEFAULT_TIMEOUT = 50;
	
	/**
	 * Pinguino Product ID and Vendor ID.
	 */
	private final static int VID = 0x04D8;
	private final static int PID = 0xFEAA;
	
	/**
	 * printout messages while set to true.
	 */
	private static boolean LOGGER = false;
	
	
	/** Processing applet object */
	private PApplet parent;
	/** USB device object */
	private Device device;
	
	/**
	 * The last error message
	 */
	public static String errmsg = "";
	
	
	
	
	
	/**
	 * Create a new Pinguino object and initialize board connection.
	 *
	 * @invisible
	 */
	public Pinguino() {
		this(null);
	}
	
	
	/**
	 * Create a new Pinguino object and initialize board connection.
	 *
	 * @param parent	the Processing PApplet object (typically use "this")
	 *
	 * @example	pinguino
	 */
	public Pinguino( PApplet parent ) {
		
		this.parent = parent;
		
		// update paths and register this object to the PApplet, 
		// while this library is used with Processing
		try {
			if ( parent instanceof PApplet )
				((PApplet)parent).registerDispose( this );
		}
		catch( NoClassDefFoundError e ) {;}
		
		
		// initialize libUSB
		// and figure out Pinguino device
		LibusbJava.usb_init(); 
		LibusbJava.usb_find_busses();
		LibusbJava.usb_find_devices();
		try {
			device = USB.getDevice( (short)VID, (short)PID );
			device.open( 3, 0, -1 );
			printout( "Pinguino found" );
		}
		catch( USBException e ) {
			printerr( "initialization failed\n"+e.getMessage() ); 
		}
		
	}
	
	
	/**
	 * Clear all pins value and close device connection.
	 * This method is automatically called by Processing when the PApplet shuts down.
	 *
	 * @invisible
	 */
	public void dispose() {
		try {
			clear();
			device.close();
		}
		catch( USBException e ) {}
	}
	
	
	
	// -- SENDING DATA TO PINGUINO -----------------------------------------------------------------
	
	/**
	 * Send the given data to Pinguino device.
	 * @description Send the given data to Pinguino device with an optional timeout value.
	 *
	 * @param data    data as byte array to be sent
	 *
	 * @see #write( byte[] )
	 * @see #read( byte[] )
	 * @see #read( byte[], int )
	 *
	 * @example	readwrite
	 */
	public void write( byte[] data ) {
		write( data, DEFAULT_TIMEOUT );
	} 
	
	
	/**
	 * Send the given data to Pinguino device with an optional timeout value.
	 *
	 * @param data       data as byte array to be sent
	 * @param timeout    amount of time in milliseconds the device will try to send the data
	 *
	 * @see #write( byte[] )
	 * @see #read( byte[] )
	 * @see #read( byte[], int )
	 *
	 * @example readwrite
	 */
	public void write( byte[] data, int timeout ) {
		try {
			device.writeBulk( 0x01, data, data.length, timeout, false );
		}
		catch( USBException e ) { printerr(e.getMessage()); }
	}
	
	
	/**
	 * Send the given value to the specified pin number.
	 *
	 * @param pin      the target pin number
	 * @param value    the new pin value ( 1, HIGH, 0, LOW )
	 *
	 * @see #HIGH
	 * @see #LOW
	 * @see #analogWrite( int, int )
	 *
	 * @example digitalwrite
	 */
	public void digitalWrite( int pin, int value ) {
		byte[] request = new byte[] { '+', 'W', 'D', (byte)pin, (byte)value, 0 };
		write( request );
	}
	
	
	/**
	 * Send the given value to the specified analog pin number.
	 *
	 * @param pin      the target pin number
	 * @param value    the new pin value ( 0 - 1024 )
	 *
	 * @see #digitalWrite( int, int )
	 * @example analogwrite
	 */
	public void analogWrite( int pin, int value ) {
		
		int b1 = value - (value/256) * 256;
		int b2 = value/256;
		
		byte[] request = new byte[] { '+', 'W', 'A', (byte)pin, (byte)b1, (byte)b2, 0 };
		
		write( request );
	}
	
	
	
	// -- RECEIVING DATA FROM PINGUINO -------------------------------------------------------------
	
	/**
	 * Retrieve the latest message from Pinguino device with the default timeout value.
	 * @description Retrieve the latest message from Pinguino device with an optional timeout value.
	 *
	 * @param result   the data list to be returned
	 *
	 * @see #read( byte[], int )
	 * @see #write( byte[], int )
	 * @see #write( byte[] )
	 *
	 * @example readwrite
	 */
	public byte[] read( byte[] result ) {
		return read( result, DEFAULT_TIMEOUT );
	}
	
	
	/**
	 * Retrieve the latest message from Pinguino device with an optional timeout value.
	 *
	 * @param result   the data list to be returned
	 * @param timeout  amount of time in milliseconds the device will try to give the data
	 *
	 * @see #read( byte[] )
	 * @see #write( byte[] )
	 * @see #write( byte[], int )
	 *
	 * @example readwrite
	 */
	public byte[] read( byte[] result, int timeout ) {
		try {
			device.readBulk( 0x82, result, result.length, timeout, false );
			return result;
		}
		catch( USBException e ) { printerr(e.getMessage()); }
		return null;
	}
	
	
	/**
	 * Retrieve the specified digital pin value.
	 *
	 * @param pin	the pin index
	 * @return int	the pin value 0 (LOW) or 1 (HIGH), or -1 on error
	 *
	 * @see #digitalWrite( int, int )
	 * @see #analogWrite( int, int )
	 * @see #analogRead( int )
	 *
	 * @example digitalread
	 */
	public int digitalRead( int pin ) {
		
		byte[] request = new byte[] { '+', 'R', 'D', (byte)pin, 0 };
		byte[] buffer  = new byte[1];
		
		//  send the request and read the response
		write( request );
		buffer = read( buffer );
		
		// return value
		return buffer==null ? -1 : buffer[0];
	}
	
	
	/**
	 * Retrieve the specified analog pin value.
	 *
	 * @param pin	the pin index
	 * @return int	the pin value (0-1024) or -1 on error
	 *
	 * @see #analogWrite( int, int )
	 * @see #digitalWrite( int, int )
	 * @see #digitalRead( int )
	 *
	 * @example analogread
	 */
	public int analogRead( int pin ) {
		
		byte[] request = new byte[] { '+', 'R', 'A', (byte)pin, 0 };
		byte[] buffer  = new byte[2];
		
		//  send the request and read the response
		write( request );
		buffer = read( buffer );
		
		// error
		if ( buffer==null ) return -1;
		
		// convert MSB byte
		int i= ( buffer[0]>=0 ) ? (int)buffer[0] : (int)( 256+buffer[0] );
		
		// return value
		return i+256*buffer[1];
	}
	
	
	
	// -- USEFULL METHODs --------------------------------------------------------------------------
	
	/**
	 * Clear all pin values.
	 */
	public void clear() {
		write( new byte[]{ '+', 'W', 'C', 0 } );
	}
	
	
	
	// -- IN/OUT MESSAGEs --------------------------------------------------------------------------
	
	/**
	 * Enable/disable status updates.<br />
	 * This method is static and should be called before creating the Pinguino object.
	 *
	 * @param enable	enable/disable status updates, disabled by default
	 * @example log
	 */
	public static void log( boolean enable ) {
		LOGGER = enable;
	}
	
	/**
	 * Print message in console.
	 *
	 * @param msg    the message to be printed
	 */
	private static void printout( String msg ) {
		if ( LOGGER ) System.out.println( msg );
	}
	
	/**
	 * Print error message in console.
	 *
	 * @param msg    the message to be printed
	 */
	private static void printerr( String msg ) {
		if ( !errmsg.equals(msg) ) {
			System.err.println( "!!! Pinguino error : "+msg );
			errmsg = msg;
		}
	}
	
}