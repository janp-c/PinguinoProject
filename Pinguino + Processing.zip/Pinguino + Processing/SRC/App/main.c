/**
 *  main.c
 *  Pinguino
 */


#include <stdlib.h>
#include <string.h>

int main( int argc, char* argv[] ) {
	
	char py[] = "python ";
	char root[] = "/MacOS/Pinguino-beta5";
	char file[] = "/Resources/pinguinobeta5.py";
	char cmd[ strlen(py)+strlen(argv[0])-strlen(root)+strlen(file) ];
	
	strncat( cmd, py, strlen(py) );
	strncat( cmd, argv[0], strlen(argv[0])-strlen(root) );
	strncat( cmd, file, strlen(file) );
	
	int err = system( cmd );
	return err;
}
